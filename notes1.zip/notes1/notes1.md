# Notes 1

## What is Markdown?
Answer to the question goes here. 
Markdown is a markup language that allows you to write plain text documents with lightweight formatting choices.


## What is Git?
Answer to the question goes here. 
Git is a underlying version control system that runs on local machines and allows you to track changes in coding.


## What is GitHub?
Answer to the question goes here. 
An open source community where people all over the globe can work on different coding projects.


## What is Slack
Answer to the question goes here. 
Slack is an instantaneous messaging program.
